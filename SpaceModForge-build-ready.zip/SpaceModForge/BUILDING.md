# Building SpaceMod for Minecraft 1.20.1 + Forge

## Requirements
- 64-bit JDK 17 (Minecraft/Forge 1.20.1 target)
- Gradle installed, or open the folder in IntelliJ IDEA with Gradle support
- Internet access on the first build so Gradle can download Forge/Minecraft dependencies

## Build on Windows
1. Install/select JDK 17 and confirm `java -version` reports version 17.
2. Install Gradle and make sure `gradle --version` works in Command Prompt, or open this folder in IntelliJ IDEA and import it as a Gradle project.
3. From this folder run `build.bat` or run `gradle build`.
4. If compilation succeeds, the mod jar will be in `build\libs\spacemod-1.0.0.jar`.
5. Copy that jar into `%appdata%\.minecraft\mods` and launch the Forge 1.20.1 profile.

If the build fails, share the full first compiler error and the lines around it. Do not copy the source ZIP itself into the `mods` folder.
