@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found on PATH.
  echo Install Gradle or open this project in IntelliJ IDEA and use its Gradle integration.
  echo Minecraft 1.20.1 Forge builds should use Java 17.
  pause
  exit /b 1
)
gradle build
if errorlevel 1 (
  echo Build failed. Copy the full error output so it can be diagnosed.
  pause
  exit /b 1
)
echo Build successful. Look for build\libs\spacemod-1.0.0.jar
pause
