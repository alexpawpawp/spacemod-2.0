package com.spacemod.plant;

import com.spacemod.ModBlocks;
import com.spacemod.SpaceMod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * На инопланетных измерениях ванильные и космические культуры
 * растут только в радиусе космического купола.
 */
@Mod.EventBusSubscriber(modid = SpaceMod.MOD_ID)
public class DomeGrowthHandler {

    private static final int DOME_RADIUS = 12;

    public static boolean isUnderDome(Level level, BlockPos pos) {
        if (!level.dimension().location().getNamespace().equals(SpaceMod.MOD_ID)) {
            return true; // на Земле без ограничений
        }
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -DOME_RADIUS; dx <= DOME_RADIUS; dx++) {
            for (int dy = -4; dy <= 8; dy++) {
                for (int dz = -DOME_RADIUS; dz <= DOME_RADIUS; dz++) {
                    m.set(pos.getX() + dx, pos.getY() + dy, pos.getZ() + dz);
                    BlockState st = level.getBlockState(m);
                    if (st.is(ModBlocks.SPACE_DOME.get())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @SubscribeEvent
    public static void onCropGrow(BlockEvent.CropGrowEvent.Pre event) {
        if (!(event.getLevel() instanceof Level level)) return;
        if (!level.dimension().location().getNamespace().equals(SpaceMod.MOD_ID)) return;
        if (!isUnderDome(level, event.getPos())) {
            event.setResult(Event.Result.DENY);
        }
    }
}
