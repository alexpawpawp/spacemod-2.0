package com.spacemod.plant;

import com.spacemod.ModItems;
import com.spacemod.SpaceMod;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Эффекты от инопланетной еды. Какие опасны — не подсказываем в игре.
 */
@Mod.EventBusSubscriber(modid = SpaceMod.MOD_ID)
public class AlienFoodHandler {

    @SubscribeEvent
    public static void onUseFinish(LivingEntityUseItemEvent.Finish event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (player.level().isClientSide) return;
        Item item = event.getItem().getItem();

        // Разные эффекты; часть вредная — игрок узнает сам
        if (item == ModItems.MARS_BERRY.get()) {
            player.getFoodData().eat(2, 0.3f);
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0));
        } else if (item == ModItems.EUROPA_FRUIT.get()) {
            player.getFoodData().eat(3, 0.4f);
            player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 300, 0));
        } else if (item == ModItems.TITAN_FUNGUS.get()) {
            player.getFoodData().eat(2, 0.2f);
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0));
        } else if (item == ModItems.PROXIMA_POD.get()) {
            player.getFoodData().eat(1, 0.1f);
            player.addEffect(new MobEffectInstance(MobEffects.POISON, 120, 0));
        } else if (item == ModItems.VENUS_POD.get()) {
            player.getFoodData().eat(2, 0.1f);
            player.hurt(player.damageSources().magic(), 4);
            player.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0));
        } else if (item == ModItems.TRAPPIST_APPLE.get()) {
            player.getFoodData().eat(4, 0.5f);
            player.heal(2);
        } else if (item == ModItems.WOLF_BERRY.get()) {
            player.getFoodData().eat(2, 0.2f);
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 0));
        } else if (item == ModItems.CANCRI_FRUIT.get()) {
            player.getFoodData().eat(1, 0.1f);
            player.setSecondsOnFire(4);
        } else if (item == ModItems.VOID_SPORES.get()) {
            player.getFoodData().eat(1, 0.1f);
            player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 0));
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 150, 0));
        } else if (item == ModItems.ICE_PETAL.get()) {
            player.getFoodData().eat(2, 0.3f);
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0));
        }
    }
}
