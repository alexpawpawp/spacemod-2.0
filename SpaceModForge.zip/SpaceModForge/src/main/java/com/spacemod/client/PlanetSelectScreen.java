package com.spacemod.client;

import com.spacemod.data.SpaceData;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Простое GUI выбора планеты.
 * Открывается при Shift+ПКМ ракетой (в клиентском коде).
 */
public class PlanetSelectScreen extends Screen {

    private final ItemStack rocketStack;
    private final List<String> destinations = new ArrayList<>();
    private int scroll = 0;
    private static final int VISIBLE = 8;

    public PlanetSelectScreen(ItemStack rocketStack) {
        super(Component.literal("Выбор цели полёта"));
        this.rocketStack = rocketStack;

        for (SpaceData.Planet p : SpaceData.PLANETS) destinations.add(p.name());
        for (SpaceData.Planet p : SpaceData.MOONS) destinations.add(p.name());
        for (SpaceData.StarSystem sys : SpaceData.STAR_SYSTEMS) {
            for (SpaceData.Planet p : sys.planets()) destinations.add(p.name());
        }
        destinations.add("Стрелец A*");
        destinations.add("M87*");
        destinations.add("Открытый космос");
    }

    @Override
    protected void init() {
        int startY = 40;
        for (int i = 0; i < VISIBLE; i++) {
            final int idx = scroll + i;
            if (idx >= destinations.size()) break;
            String name = destinations.get(idx);
            addRenderableWidget(Button.builder(Component.literal(name), b -> select(name))
                    .bounds(width / 2 - 100, startY + i * 22, 200, 20)
                    .build());
        }

        // Кнопки прокрутки
        if (scroll > 0) {
            addRenderableWidget(Button.builder(Component.literal("↑"), b -> {
                scroll = Math.max(0, scroll - VISIBLE);
                rebuildWidgets();
            }).bounds(width / 2 - 100, height - 40, 90, 20).build());
        }
        if (scroll + VISIBLE < destinations.size()) {
            addRenderableWidget(Button.builder(Component.literal("↓"), b -> {
                scroll = Math.min(destinations.size() - VISIBLE, scroll + VISIBLE);
                rebuildWidgets();
            }).bounds(width / 2 + 10, height - 40, 90, 20).build());
        }
    }

    private void select(String name) {
        // Сохраняем выбранную цель в NBT ракеты
        rocketStack.getOrCreateTag().putString("SelectedDest", name);
        if (minecraft != null && minecraft.player != null) {
            minecraft.player.sendSystemMessage(Component.literal("§aЦель установлена: §e" + name));
            minecraft.player.sendSystemMessage(Component.literal("§7Теперь обычный ПКМ ракетой — запуск к этой цели."));
        }
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        g.drawCenteredString(font, title, width / 2, 15, 0xFFFFFF);
        g.drawCenteredString(font, "Выберите планету / спутник / экзопланету", width / 2, 28, 0xAAAAAA);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
