package com.spacemod.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import com.spacemod.SpaceMod;

/**
 * Многочастная модель ракеты (корпус + нос + двигатели).
 */
public class RocketModel<T extends Entity> extends EntityModel<T> {

    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            new ResourceLocation(SpaceMod.MOD_ID, "rocket"), "main");

    private final ModelPart body;
    private final ModelPart nose;
    private final ModelPart finLeft;
    private final ModelPart finRight;
    private final ModelPart engine;

    public RocketModel(ModelPart root) {
        this.body = root.getChild("body");
        this.nose = root.getChild("nose");
        this.finLeft = root.getChild("fin_left");
        this.finRight = root.getChild("fin_right");
        this.engine = root.getChild("engine");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4, 0, -4, 8, 20, 8),
                PartPose.offset(0, 0, 0));

        root.addOrReplaceChild("nose", CubeListBuilder.create()
                .texOffs(32, 0).addBox(-3, 20, -3, 6, 8, 6),
                PartPose.offset(0, 0, 0));

        root.addOrReplaceChild("fin_left", CubeListBuilder.create()
                .texOffs(0, 28).addBox(-8, 0, -1, 4, 8, 2),
                PartPose.offset(0, 0, 0));

        root.addOrReplaceChild("fin_right", CubeListBuilder.create()
                .texOffs(0, 28).addBox(4, 0, -1, 4, 8, 2),
                PartPose.offset(0, 0, 0));

        root.addOrReplaceChild("engine", CubeListBuilder.create()
                .texOffs(32, 14).addBox(-3, -4, -3, 6, 4, 6),
                PartPose.offset(0, 0, 0));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        // лёгкое покачивание при полёте можно добавить позже
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        body.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        nose.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        finLeft.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        finRight.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
        engine.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
