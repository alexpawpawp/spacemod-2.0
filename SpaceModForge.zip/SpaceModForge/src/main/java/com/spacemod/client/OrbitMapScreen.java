package com.spacemod.client;

import com.spacemod.orbit.OrbitSimulator;
import com.spacemod.orbit.OrbitSimulator.Body;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Орбитальная карта Солнечной системы.
 * Планеты движутся по круговым орбитам в реальном времени GUI.
 */
public class OrbitMapScreen extends Screen {

    private double time;
    private float zoom = 1.0f;
    private boolean running = true;

    public OrbitMapScreen() {
        super(Component.literal("Орбитальная карта"));
        this.time = OrbitSimulator.getTime();
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal(running ? "⏸ Пауза" : "▶ Пуск"), b -> {
            running = !running;
            b.setMessage(Component.literal(running ? "⏸ Пауза" : "▶ Пуск"));
        }).bounds(10, height - 30, 80, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Зум +"), b -> zoom = Math.min(3f, zoom + 0.25f))
                .bounds(100, height - 30, 60, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Зум −"), b -> zoom = Math.max(0.3f, zoom - 0.25f))
                .bounds(170, height - 30, 60, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Закрыть"), b -> onClose())
                .bounds(width - 90, height - 30, 80, 20).build());
    }

    @Override
    public void tick() {
        if (running) {
            time += 2.0; // ускорение: ~2 дня за тик GUI
            OrbitSimulator.setTime(time);
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);

        int cx = width / 2;
        int cy = height / 2 - 10;
        double scale = 8.0 * zoom; // пикселей на а.е.

        // Солнце
        g.fill(cx - 6, cy - 6, cx + 6, cy + 6, 0xFFFFFF00);
        g.drawCenteredString(font, "☉ Солнце", cx, cy - 18, 0xFFFF88);

        // Орбиты и планеты
        for (Body body : OrbitSimulator.SOLAR_SYSTEM) {
            int r = (int) (body.orbitRadius() * scale);
            // орбита (круг точками)
            for (int a = 0; a < 360; a += 8) {
                double rad = Math.toRadians(a);
                int ox = cx + (int) (Math.cos(rad) * r);
                int oy = cy + (int) (Math.sin(rad) * r);
                g.fill(ox, oy, ox + 1, oy + 1, 0x44FFFFFF);
            }
            // планета
            double ang = body.angle(time);
            int px = cx + (int) (Math.cos(ang) * r);
            int py = cy + (int) (Math.sin(ang) * r);
            int s = Math.max(2, (int) (body.size() * 0.5 * zoom));
            int col = 0xFF000000 | body.color();
            g.fill(px - s, py - s, px + s, py + s, col);
            g.drawString(font, body.name(), px + s + 2, py - 4, 0xFFFFFF);
        }

        g.drawCenteredString(font, "§6Орбитальная карта Солнечной системы", width / 2, 8, 0xFFFFFF);
        g.drawCenteredString(font, String.format("Время: %.0f дней | Зум: %.1fx", time, zoom), width / 2, 20, 0xAAAAAA);
        g.drawString(font, "Планеты движутся по круговым орбитам (упрощённая модель)", 10, height - 50, 0x888888);

        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
