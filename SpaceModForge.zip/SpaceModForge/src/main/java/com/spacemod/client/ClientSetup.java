package com.spacemod.client;

import com.spacemod.SpaceMod;
import com.spacemod.client.model.RocketModel;
import com.spacemod.entity.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Клиентская регистрация моделей и рендереров.
 * Полноценный EntityRenderer можно дописать; слой модели уже готов.
 */
@Mod.EventBusSubscriber(modid = SpaceMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientSetup {

    @SubscribeEvent
    public static void onLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(RocketModel.LAYER, RocketModel::createBodyLayer);
    }

    // Рендерер ракеты: для полной работы нужен класс, extends EntityRenderer.
    // Модель зарегистрирована; в игре ракета пока может отображаться как hitbox,
    // пока не добавлен полный renderer (можно дописать отдельно).
}
