package com.spacemod.client;

import com.spacemod.data.SpaceData;
import com.spacemod.orbit.OrbitSimulator;
import com.spacemod.orbit.OrbitSimulator.Body;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * «Камера зонда» — вид на космос с орбитальной картой и описанием объекта.
 * Не полноценный 3D-рендер, но имитация обзора из зонда.
 */
public class ProbeCameraScreen extends Screen {

    private int targetIndex = 0;
    private double time;
    private final String[] targets;

    public ProbeCameraScreen() {
        super(Component.literal("Камера зонда"));
        this.time = OrbitSimulator.getTime();
        // Цели: планеты + чёрные дыры + deep space
        java.util.List<String> list = new java.util.ArrayList<>();
        for (Body b : OrbitSimulator.SOLAR_SYSTEM) list.add(b.name());
        list.add("Стрелец A*");
        list.add("M87*");
        for (var o : SpaceData.DEEP_SPACE_OBJECTS) list.add(o.type() + " «" + o.name() + "»");
        this.targets = list.toArray(new String[0]);
    }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("◀ Предыдущий"), b -> {
            targetIndex = (targetIndex - 1 + targets.length) % targets.length;
        }).bounds(10, height - 30, 110, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Следующий ▶"), b -> {
            targetIndex = (targetIndex + 1) % targets.length;
        }).bounds(130, height - 30, 110, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Закрыть"), b -> onClose())
                .bounds(width - 90, height - 30, 80, 20).build());
    }

    @Override
    public void tick() {
        time += 1.5;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        // Тёмный фон космоса
        g.fill(0, 0, width, height, 0xFF020208);

        // «Звёзды»
        for (int i = 0; i < 120; i++) {
            int sx = (i * 97 + (int) time) % width;
            int sy = (i * 53) % (height - 40);
            int bright = 150 + (i % 100);
            g.fill(sx, sy, sx + 1, sy + 1, 0xFF000000 | (bright << 16) | (bright << 8) | bright);
        }

        String target = targets[targetIndex];
        g.drawCenteredString(font, "§b§lКАМЕРА ЗОНДА", width / 2, 10, 0x55FFFF);
        g.drawCenteredString(font, "§fЦель: §e" + target, width / 2, 24, 0xFFFFFF);

        // Мини-орбитальная схема в центре
        int cx = width / 2;
        int cy = height / 2 - 20;
        g.fill(cx - 4, cy - 4, cx + 4, cy + 4, 0xFFFFFF00); // солнце

        for (Body body : OrbitSimulator.SOLAR_SYSTEM) {
            double r = body.orbitRadius() * 6;
            double ang = body.angle(time);
            int px = cx + (int) (Math.cos(ang) * r);
            int py = cy + (int) (Math.sin(ang) * r);
            int col = 0xFF000000 | body.color();
            int s = Math.max(1, (int) (body.size() * 0.3));
            g.fill(px - s, py - s, px + s, py + s, col);
            if (body.name().equals(target) || target.startsWith(body.name())) {
                // подсветка цели
                g.fill(px - s - 2, py - s - 2, px + s + 2, py + s + 2, 0x88FFFFFF);
            }
        }

        // Описание
        String desc = getDescription(target);
        int ty = height - 80;
        for (String line : desc.split("\n")) {
            g.drawCenteredString(font, line, width / 2, ty, 0xCCCCCC);
            ty += 12;
        }

        g.drawString(font, "§8Зонд на безопасной дистанции. Данные передаются на станцию.", 10, height - 50, 0x666666);
        super.render(g, mouseX, mouseY, partial);
    }

    private String getDescription(String target) {
        if (target.contains("Стрелец") || target.contains("M87")) {
            return "§5Чёрная дыра\nГоризонт событий. Сильное искривление пространства-времени.\nНаучные данные: гравитационные волны / энергия аккреционного диска.";
        }
        for (Body b : OrbitSimulator.SOLAR_SYSTEM) {
            if (b.name().equals(target)) {
                return "§7Орбитальный радиус: §f" + b.orbitRadius() + " а.е.\n§7Период обращения: §f" + (int) b.periodDays() + " земных дней\n§7Зонд фиксирует спектр и изображение диска.";
            }
        }
        for (var o : SpaceData.DEEP_SPACE_OBJECTS) {
            String full = o.type() + " «" + o.name() + "»";
            if (full.equals(target)) {
                return "§7" + o.description() + "\n§aНаходка: §f" + o.researchReward();
            }
        }
        return "§7Наблюдение объекта...";
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
