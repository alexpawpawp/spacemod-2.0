package com.spacemod.mission;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Кампания экспедиций из оригинального кода.
 * Хранится в persistent data игрока.
 */
public class MissionManager {

    public record Mission(String name, String destination, String objective, String reward,
                          int requiredResearch, int danger, int researchReward) {}

    public static final List<Mission> MISSIONS = List.of(
            new Mission("Первый сигнал", "Орбитальная станция", "проверить связь и навигацию", "чертёж улучшенного радара", 0, 1, 14),
            new Mission("Охотники за астероидами", "Пояс астероидов", "собрать образцы железа и никеля", "железо и никель", 10, 2, 14),
            new Mission("Ледяной дозор", "Европа", "просканировать ледяную кору", "образец подлёдного океана", 20, 3, 16),
            new Mission("Пески Марса", "Марс", "найти следы древней воды", "марсианский лёд", 32, 2, 16),
            new Mission("Штормовой рубеж", "орбита Юпитера", "измерить магнитное поле гиганта", "данные о магнитосфере", 45, 4, 18),
            new Mission("Туманный архив", "Туманность Ориона", "изучить облака газа и пыли", "образец космической пыли", 58, 3, 18),
            new Mission("Море Титана", "Титан", "снять карту метановых озёр", "метан и этан", 72, 3, 20),
            new Mission("Граница системы", "Пояс Койпера", "обнаружить новые ледяные тела", "редкий ледяной минерал", 86, 5, 22)
    );

    private static final String KEY = "SpaceModMissions";

    public static CompoundTag getData(Player player) {
        CompoundTag persistent = player.getPersistentData();
        if (!persistent.contains(KEY)) {
            CompoundTag data = new CompoundTag();
            data.putInt("Research", 0);
            data.putInt("Credits", 0);
            data.put("Completed", new ListTag());
            data.put("Tech", new ListTag());
            persistent.put(KEY, data);
        }
        return persistent.getCompound(KEY);
    }

    public static void tryCompleteNext(ServerPlayer player) {
        CompoundTag data = getData(player);
        int research = data.getInt("Research");
        ListTag completed = data.getList("Completed", 8);

        for (Mission m : MISSIONS) {
            if (completed.contains(StringTag.valueOf(m.name()))) continue;

            if (research < m.requiredResearch()) {
                player.sendSystemMessage(Component.literal("§cМиссия «" + m.name() + "» недоступна. Нужно " + m.requiredResearch() + " очков исследований (сейчас " + research + ")."));
                return;
            }

            // Выполняем
            player.sendSystemMessage(Component.literal("§6--- Миссия: " + m.name() + " ---"));
            player.sendSystemMessage(Component.literal("§7Пункт: " + m.destination()));
            player.sendSystemMessage(Component.literal("§7Задача: " + m.objective()));
            player.sendSystemMessage(Component.literal("§7Опасность: " + m.danger() + "/5"));

            research += m.researchReward();
            int credits = data.getInt("Credits") + m.researchReward() * 25;
            completed.add(StringTag.valueOf(m.name()));

            data.putInt("Research", research);
            data.putInt("Credits", credits);
            data.put("Completed", completed);

            player.sendSystemMessage(Component.literal("§aМиссия выполнена! Награда: " + m.reward()));
            player.sendSystemMessage(Component.literal("§b+" + m.researchReward() + " исследований. Всего: " + research + " | Кредиты: " + credits));

            unlockTech(player, data, research);
            return;
        }
        player.sendSystemMessage(Component.literal("§aВсе миссии кампании выполнены!"));
    }

    private static void unlockTech(ServerPlayer player, CompoundTag data, int research) {
        ListTag tech = data.getList("Tech", 8);
        checkTech(player, tech, research, 20, "Усиленный сканер");
        checkTech(player, tech, research, 45, "Ионный двигатель");
        checkTech(player, tech, research, 72, "Анализатор экзоматерии");
        checkTech(player, tech, research, 100, "Квантовая связь");
        data.put("Tech", tech);
    }

    private static void checkTech(ServerPlayer player, ListTag tech, int research, int need, String name) {
        if (research >= need && !tech.contains(StringTag.valueOf(name))) {
            tech.add(StringTag.valueOf(name));
            player.sendSystemMessage(Component.literal("§d§lОткрыта технология: " + name + "!"));
        }
    }

    public static void showStatus(ServerPlayer player) {
        CompoundTag data = getData(player);
        player.sendSystemMessage(Component.literal("§6=== Статус кампании ==="));
        player.sendSystemMessage(Component.literal("§7Исследования: " + data.getInt("Research")));
        player.sendSystemMessage(Component.literal("§7Кредиты: " + data.getInt("Credits")));
        ListTag completed = data.getList("Completed", 8);
        player.sendSystemMessage(Component.literal("§7Выполнено миссий: " + completed.size() + "/" + MISSIONS.size()));
        ListTag tech = data.getList("Tech", 8);
        if (tech.isEmpty()) {
            player.sendSystemMessage(Component.literal("§7Технологии: пока нет"));
        } else {
            List<String> names = new ArrayList<>();
            for (int i = 0; i < tech.size(); i++) names.add(tech.getString(i));
            player.sendSystemMessage(Component.literal("§7Технологии: " + String.join(", ", names)));
        }
    }
}
