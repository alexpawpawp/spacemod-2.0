package com.spacemod;

import com.mojang.logging.LogUtils;
import com.spacemod.data.SpaceData;
import com.spacemod.entity.ModEntities;
import com.spacemod.sound.ModSounds;
import com.spacemod.suit.SuitSurvivalHandler;
import com.spacemod.suit.SuitType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

@Mod(SpaceMod.MOD_ID)
public class SpaceMod {
    public static final String MOD_ID = "spacemod";
    private static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final RegistryObject<CreativeModeTab> SPACE_TAB = CREATIVE_TABS.register("space_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.spacemod"))
                    .icon(() -> new ItemStack(ModItems.ROCKET.get()))
                    .displayItems((params, output) -> ModItems.ITEMS.getEntries().forEach(i -> output.accept(i.get())))
                    .build());

    public SpaceMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.register(bus);
        ModBlocks.register(bus);
        ModEntities.register(bus);
        ModSounds.register(bus);
        CREATIVE_TABS.register(bus);
        bus.addListener(this::setup);
        MinecraftForge.EVENT_BUS.register(this);
        LOGGER.info("Космический мод: Марс, Луна, Европа, ракеты, мобы, GUI — загружены.");
    }

    private void setup(FMLCommonSetupEvent e) {
        LOGGER.info("Данные: {} планет, {} систем, {} мобов", SpaceData.PLANETS.size(), SpaceData.STAR_SYSTEMS.size(), SpaceData.ALIEN_MOBS.size());
        SuitSurvivalHandler.bind(SuitType.BASIC, ModItems.BASIC_SUIT);
        SuitSurvivalHandler.bind(SuitType.HEAT, ModItems.HEAT_SUIT);
        SuitSurvivalHandler.bind(SuitType.COLD, ModItems.COLD_SUIT);
        SuitSurvivalHandler.bind(SuitType.PRESSURE, ModItems.PRESSURE_SUIT);
        SuitSurvivalHandler.bind(SuitType.RADIATION, ModItems.RADIATION_SUIT);
        SuitSurvivalHandler.bind(SuitType.TOXIC, ModItems.TOXIC_SUIT);
        SuitSurvivalHandler.bind(SuitType.VACUUM, ModItems.VACUUM_SUIT);
        SuitSurvivalHandler.bind(SuitType.GIANT, ModItems.GIANT_SUIT);
        SuitSurvivalHandler.bind(SuitType.STAR, ModItems.STAR_SUIT);
    }
}
