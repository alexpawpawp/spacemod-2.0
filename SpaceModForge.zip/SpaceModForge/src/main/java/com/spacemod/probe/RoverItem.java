package com.spacemod.probe;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class RoverItem extends Item {
    public RoverItem(Properties props) { super(props); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!level.isClientSide) {
            var pos = ctx.getClickedPos().relative(ctx.getClickedFace());
            RoverEntity rover = new RoverEntity(level, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            level.addFreshEntity(rover);
            if (!ctx.getPlayer().getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
            ctx.getPlayer().sendSystemMessage(Component.literal("§aПланетоход развёрнут. ПКМ по нему — начать разведку."));
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7ПКМ по блоку — развернуть зонд/марсоход"));
        tooltip.add(Component.literal("§7ПКМ по зонду — отправить на разведку"));
    }
}
