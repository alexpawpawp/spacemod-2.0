package com.spacemod.probe;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Марсоход / планетоход — можно посадить и «отправить» на разведку.
 */
public class RoverEntity extends Entity {

    private static final EntityDataAccessor<Integer> DATA_MODE =
            SynchedEntityData.defineId(RoverEntity.class, EntityDataSerializers.INT);
    // 0 = idle, 1 = exploring

    private int exploreTicks = 0;

    public RoverEntity(EntityType<?> type, Level level) {
        super(type, level);
    }

    public RoverEntity(Level level, double x, double y, double z) {
        this(com.spacemod.entity.ModEntities.ROVER.get(), level);
        setPos(x, y, z);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(DATA_MODE, 0);
    }

    @Override
    public void tick() {
        super.tick();
        if (entityData.get(DATA_MODE) == 1) {
            exploreTicks++;
            // медленное движение вперёд
            Vec3 look = getLookAngle().scale(0.08);
            setDeltaMovement(look.x, -0.05, look.z);
            move(MoverType.SELF, getDeltaMovement());
            if (exploreTicks % 100 == 0 && !level().isClientSide) {
                // «находка»
            }
            if (exploreTicks > 400) {
                entityData.set(DATA_MODE, 0);
                exploreTicks = 0;
            }
        }
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (!level().isClientSide) {
            if (entityData.get(DATA_MODE) == 0) {
                entityData.set(DATA_MODE, 1);
                exploreTicks = 0;
                player.sendSystemMessage(Component.literal("§aЗонд выпущен на маршрут разведки."));
                player.sendSystemMessage(Component.literal("§7Сканирует поверхность..."));
                // Случайный «отчёт»
                String[] finds = {
                        "§6Обнаружены минеральные включения.",
                        "§6Зафиксированы температурные аномалии.",
                        "§6Пробы грунта взяты.",
                        "§6Слабый сигнал органики.",
                        "§6Рельеф подходит для базы."
                };
                player.sendSystemMessage(Component.literal(finds[level().random.nextInt(finds.length)]));
            } else {
                entityData.set(DATA_MODE, 0);
                player.sendSystemMessage(Component.literal("§eЗонд вернулся в режим ожидания."));
            }
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public boolean isPickable() { return true; }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(DATA_MODE, tag.getInt("Mode"));
        exploreTicks = tag.getInt("ExploreTicks");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Mode", entityData.get(DATA_MODE));
        tag.putInt("ExploreTicks", exploreTicks);
    }
}
