package com.spacemod.entity;

import com.spacemod.SpaceMod;
import com.spacemod.entity.alien.*;
import com.spacemod.entity.space.PlanetCubeEntity;
import com.spacemod.probe.RoverEntity;
import com.spacemod.boss.StarGuardianEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = SpaceMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SpaceMod.MOD_ID);

    public static final RegistryObject<EntityType<RocketEntity>> ROCKET =
            ENTITY_TYPES.register("rocket", () -> EntityType.Builder.<RocketEntity>of(RocketEntity::new, MobCategory.MISC)
                    .sized(1.2f, 3.0f).clientTrackingRange(10).build("rocket"));

    public static final RegistryObject<EntityType<StarGuardianEntity>> STAR_GUARDIAN =
            ENTITY_TYPES.register("star_guardian", () -> EntityType.Builder.of(StarGuardianEntity::new, MobCategory.MONSTER)
                    .sized(2.0f, 3.5f).clientTrackingRange(16).fireImmune().build("star_guardian"));

    public static final RegistryObject<EntityType<RoverEntity>> ROVER =
            ENTITY_TYPES.register("rover", () -> EntityType.Builder.<RoverEntity>of(RoverEntity::new, MobCategory.MISC)
                    .sized(1.2f, 0.8f).clientTrackingRange(10).build("rover"));

    public static final RegistryObject<EntityType<PlanetCubeEntity>> PLANET_CUBE =
            ENTITY_TYPES.register("planet_cube", () -> EntityType.Builder.<PlanetCubeEntity>of(PlanetCubeEntity::new, MobCategory.MISC)
                    .sized(8f, 8f).clientTrackingRange(128).fireImmune().build("planet_cube"));

    public static final RegistryObject<EntityType<IceMicrobeEntity>> ICE_MICROBE = mob("ice_microbe", IceMicrobeEntity::new, 0.6f, 0.6f, false);
    public static final RegistryObject<EntityType<MethaneSwimmerEntity>> METHANE_SWIMMER = mob("methane_swimmer", MethaneSwimmerEntity::new, 0.8f, 0.6f, false);
    public static final RegistryObject<EntityType<DustHunterEntity>> DUST_HUNTER = mob("dust_hunter", DustHunterEntity::new, 1.0f, 1.2f, true);
    public static final RegistryObject<EntityType<CrystalWandererEntity>> CRYSTAL_WANDERER = mob("crystal_wanderer", CrystalWandererEntity::new, 0.9f, 1.0f, false);
    public static final RegistryObject<EntityType<RedDiggerEntity>> RED_DIGGER = mob("red_digger", RedDiggerEntity::new, 0.8f, 0.7f, false);
    public static final RegistryObject<EntityType<LuytenReefEntity>> LUYTEN_REEF = mob("luyten_reef", LuytenReefEntity::new, 1.2f, 0.8f, false);
    public static final RegistryObject<EntityType<TwilightSailorEntity>> TWILIGHT_SAILOR = mob("twilight_sailor", TwilightSailorEntity::new, 0.7f, 0.5f, false);
    public static final RegistryObject<EntityType<CrystalCrawlerEntity>> CRYSTAL_CRAWLER = mob("crystal_crawler", CrystalCrawlerEntity::new, 0.5f, 0.4f, false);
    public static final RegistryObject<EntityType<WolfThunderEntity>> WOLF_THUNDER = mob("wolf_thunder", WolfThunderEntity::new, 1.4f, 1.5f, true);
    public static final RegistryObject<EntityType<LavaShellEntity>> LAVA_SHELL = mob("lava_shell", LavaShellEntity::new, 1.3f, 1.1f, true);
    public static final RegistryObject<EntityType<ProxLightEntity>> PROX_LIGHT = mob("prox_light", ProxLightEntity::new, 0.4f, 0.4f, false);

    // Дополнительные агрессивные
    public static final RegistryObject<EntityType<SpaceRaiderEntity>> SPACE_RAIDER = mob("space_raider", SpaceRaiderEntity::new, 1.1f, 1.8f, true);
    public static final RegistryObject<EntityType<VoidStalkerEntity>> VOID_STALKER = mob("void_stalker", VoidStalkerEntity::new, 1.2f, 1.4f, true);

    private static <T extends net.minecraft.world.entity.PathfinderMob> RegistryObject<EntityType<T>> mob(
            String id, EntityType.EntityFactory<T> factory, float w, float h, boolean hostile) {
        return ENTITY_TYPES.register(id, () -> EntityType.Builder.of(factory, hostile ? MobCategory.MONSTER : MobCategory.CREATURE)
                .sized(w, h).clientTrackingRange(10).build(id));
    }

    public static void register(IEventBus bus) { ENTITY_TYPES.register(bus); }

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ICE_MICROBE.get(), IceMicrobeEntity.createAttributes().build());
        event.put(METHANE_SWIMMER.get(), MethaneSwimmerEntity.createAttributes().build());
        event.put(DUST_HUNTER.get(), DustHunterEntity.createAttributes().build());
        event.put(CRYSTAL_WANDERER.get(), CrystalWandererEntity.createAttributes().build());
        event.put(RED_DIGGER.get(), RedDiggerEntity.createAttributes().build());
        event.put(LUYTEN_REEF.get(), LuytenReefEntity.createAttributes().build());
        event.put(TWILIGHT_SAILOR.get(), TwilightSailorEntity.createAttributes().build());
        event.put(CRYSTAL_CRAWLER.get(), CrystalCrawlerEntity.createAttributes().build());
        event.put(WOLF_THUNDER.get(), WolfThunderEntity.createAttributes().build());
        event.put(LAVA_SHELL.get(), LavaShellEntity.createAttributes().build());
        event.put(PROX_LIGHT.get(), ProxLightEntity.createAttributes().build());
        event.put(SPACE_RAIDER.get(), SpaceRaiderEntity.createAttributes().build());
        event.put(VOID_STALKER.get(), VoidStalkerEntity.createAttributes().build());
        event.put(STAR_GUARDIAN.get(), StarGuardianEntity.createAttributes().build());
    }
}
