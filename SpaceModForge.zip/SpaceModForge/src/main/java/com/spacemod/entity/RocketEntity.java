package com.spacemod.entity;

import com.spacemod.data.SpaceData;
import com.spacemod.world.BlackHoleEffects;
import com.spacemod.world.OpenSpaceManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Map;

public class RocketEntity extends Entity {

    private static final EntityDataAccessor<Integer> DATA_FUEL =
            SynchedEntityData.defineId(RocketEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> DATA_DESTINATION =
            SynchedEntityData.defineId(RocketEntity.class, EntityDataSerializers.STRING);

    private int flightTicks = 0;
    private static final int FLIGHT_DURATION = 80;
    private Player pilot = null;
    private boolean launched = false;

    /** Все посещаемые измерения: русское имя → id измерения */
    public static final Map<String, String> PLANET_DIMENSIONS = Map.ofEntries(
            Map.entry("Меркурий", "mercury"),
            Map.entry("Венера", "venus"),
            Map.entry("Земля", "earth_orbit"),
            Map.entry("Марс", "mars"),
            Map.entry("Плутон (карликовая планета)", "pluto"),
            Map.entry("Плутон", "pluto"),
            Map.entry("Луна", "moon"),
            Map.entry("Европа", "europa"),
            Map.entry("Титан", "titan"),
            Map.entry("Проксима b", "proxima_b"),
            Map.entry("Проксима d", "proxima_d"),
            Map.entry("TRAPPIST-1e", "trappist_1e"),
            Map.entry("TRAPPIST-1f", "trappist_1f"),
            Map.entry("Kepler-90i", "kepler_90i"),
            Map.entry("Глизе 667 Cc", "gliese_667_cc"),
            Map.entry("Глизе 667 Ce", "gliese_667_ce"),
            Map.entry("Тау Кита e", "tau_ceti_e"),
            Map.entry("Тау Кита f", "tau_ceti_f"),
            Map.entry("GJ 273 b", "gj273_b"),
            Map.entry("GJ 273 c", "gj273_c"),
            Map.entry("TOI 700 d", "toi700_d"),
            Map.entry("TOI 700 e", "toi700_e"),
            Map.entry("Wolf 1061 c", "wolf1061_c"),
            Map.entry("Wolf 1061 d", "wolf1061_d"),
            Map.entry("55 Cancri e", "cancri_e"),
            Map.entry("55 Cancri f", "cancri_f"),
            Map.entry("Юпитер", "jupiter"),
            Map.entry("Сатурн", "saturn"),
            Map.entry("Уран", "uranus"),
            Map.entry("Нептун", "neptune"),
            Map.entry("Kepler-90g", "kepler_90g")
    );

    public static ResourceKey<Level> dim(String id) {
        return ResourceKey.create(Registries.DIMENSION, new ResourceLocation("spacemod", id));
    }

    public RocketEntity(EntityType<?> type, Level level) {
        super(type, level);
    }

    public RocketEntity(Level level, double x, double y, double z) {
        this(ModEntities.ROCKET.get(), level);
        this.setPos(x, y, z);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_FUEL, 0);
        this.entityData.define(DATA_DESTINATION, "");
    }

    public void setFuel(int fuel) { this.entityData.set(DATA_FUEL, fuel); }
    public int getFuel() { return this.entityData.get(DATA_FUEL); }
    public void setDestination(String name) { this.entityData.set(DATA_DESTINATION, name); }
    public String getDestination() { return this.entityData.get(DATA_DESTINATION); }
    public void setPilot(Player player) { this.pilot = player; }

    public void launch() {
        if (getFuel() <= 0) {
            if (pilot != null) pilot.sendSystemMessage(Component.literal("§cНедостаточно топлива!"));
            return;
        }
        this.launched = true;
        this.flightTicks = 0;
        if (pilot != null) {
            pilot.sendSystemMessage(Component.literal("§aСтартует ракета! Цель: §e" + getDestination()));
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!launched) return;
        flightTicks++;
        this.setDeltaMovement(0, 0.55, 0);
        this.move(MoverType.SELF, this.getDeltaMovement());
        if (flightTicks >= FLIGHT_DURATION) finishFlight();
    }

    private void finishFlight() {
        if (level().isClientSide) return;
        String dest = getDestination();

        if (pilot instanceof ServerPlayer sp) {
            if (dest.equals("Открытый космос")) {
                OpenSpaceManager.enterOpenSpace(sp);
            } else if (dest.contains("Стрелец") || dest.contains("M87")) {
                BlackHoleEffects.approachBlackHole(sp, dest);
            } else if (PLANET_DIMENSIONS.containsKey(dest)) {
                teleportTo(sp, dim(PLANET_DIMENSIONS.get(dest)), dest);
            } else {
                sp.sendSystemMessage(Component.literal("§aПосадка на §e" + dest + "§a (симуляция)."));
                giveResources(sp, dest);
                checkMobs(sp, dest);
            }
        }
        this.discard();
    }

    private void teleportTo(ServerPlayer player, ResourceKey<Level> dimension, String name) {
        ServerLevel target = player.server.getLevel(dimension);
        if (target == null) {
            player.sendSystemMessage(Component.literal("§cИзмерение §e" + name + "§c не загружено. Попробуй перезайти в мир."));
            giveResources(player, name);
            checkMobs(player, name);
            return;
        }
        BlockPos pos = target.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlockPos.ZERO);
        player.teleportTo(target, pos.getX() + 0.5, pos.getY() + 1.5, pos.getZ() + 0.5, player.getYRot(), player.getXRot());
        player.sendSystemMessage(Component.literal("§a§lПосадка на §e" + name + "§a§l завершена!"));
        giveResources(player, name);
        checkMobs(player, name);
    }

    private void giveResources(ServerPlayer p, String dest) {
        SpaceData.Planet planet = findPlanet(dest);
        if (planet != null) {
            p.sendSystemMessage(Component.literal("§6Ресурсы: §f" + String.join(", ", planet.resources())));
            p.sendSystemMessage(Component.literal("§7Ракета: " + planet.rocket()));
        }
    }

    private void checkMobs(ServerPlayer p, String dest) {
        for (SpaceData.AlienMob mob : SpaceData.ALIEN_MOBS) {
            if (mob.planetName().equals(dest)) {
                p.sendSystemMessage(Component.literal("§dМоб: §f" + mob.name() + " — " + mob.description()));
                p.sendSystemMessage(Component.literal(mob.dangerous() ? "§cОпасен!" : "§aНеагрессивен"));
            }
        }
    }

    private boolean requiresOrbital(String n) {
        return n.equals("Юпитер") || n.equals("Сатурн") || n.equals("Уран") || n.equals("Нептун")
                || n.equals("Kepler-90g");
    }

    private SpaceData.Planet findPlanet(String name) {
        for (SpaceData.Planet p : SpaceData.PLANETS) if (p.name().equals(name)) return p;
        for (SpaceData.Planet p : SpaceData.MOONS) if (p.name().equals(name)) return p;
        for (SpaceData.StarSystem s : SpaceData.STAR_SYSTEMS)
            for (SpaceData.Planet p : s.planets()) if (p.name().equals(name)) return p;
        return null;
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) {
        setFuel(tag.getInt("Fuel")); setDestination(tag.getString("Destination"));
        flightTicks = tag.getInt("FlightTicks"); launched = tag.getBoolean("Launched");
    }
    @Override protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Fuel", getFuel()); tag.putString("Destination", getDestination());
        tag.putInt("FlightTicks", flightTicks); tag.putBoolean("Launched", launched);
    }
    @Override public boolean isPickable() { return !launched; }
}
