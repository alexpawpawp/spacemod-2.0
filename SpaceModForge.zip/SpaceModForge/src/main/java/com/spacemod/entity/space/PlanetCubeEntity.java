package com.spacemod.entity.space;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/**
 * Планета в виде большого цветного куба в открытом космосе.
 * Можно кликнуть, чтобы получить информацию.
 */
public class PlanetCubeEntity extends Entity {

    private static final EntityDataAccessor<String> DATA_NAME =
            SynchedEntityData.defineId(PlanetCubeEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> DATA_COLOR =
            SynchedEntityData.defineId(PlanetCubeEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_SIZE =
            SynchedEntityData.defineId(PlanetCubeEntity.class, EntityDataSerializers.FLOAT);

    public PlanetCubeEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public PlanetCubeEntity(Level level, double x, double y, double z, String name, int color, float size) {
        this(com.spacemod.entity.ModEntities.PLANET_CUBE.get(), level);
        this.setPos(x, y, z);
        setPlanetName(name);
        setPlanetColor(color);
        setPlanetSize(size);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_NAME, "Планета");
        this.entityData.define(DATA_COLOR, 0x888888);
        this.entityData.define(DATA_SIZE, 8.0f);
    }

    public void setPlanetName(String n) { this.entityData.set(DATA_NAME, n); }
    public String getPlanetName() { return this.entityData.get(DATA_NAME); }
    public void setPlanetColor(int c) { this.entityData.set(DATA_COLOR, c); }
    public int getPlanetColor() { return this.entityData.get(DATA_COLOR); }
    public void setPlanetSize(float s) { this.entityData.set(DATA_SIZE, s); }
    public float getPlanetSize() { return this.entityData.get(DATA_SIZE); }

    @Override
    public void tick() {
        super.tick();
        // Медленное вращение/покачивание визуально через позицию не делаем —
        // куб статичен, чтобы было удобно наблюдать.
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (!level().isClientSide) {
            player.sendSystemMessage(Component.literal("§6§l" + getPlanetName()));
            player.sendSystemMessage(Component.literal("§7Размер куба: §f" + getPlanetSize() + " блоков"));
            player.sendSystemMessage(Component.literal("§8Вы в открытом космосе. Используйте возвратную ракету, чтобы уйти."));
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        float s = getPlanetSize();
        return this.getBoundingBox().inflate(s);
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        setPlanetName(tag.getString("PlanetName"));
        setPlanetColor(tag.getInt("PlanetColor"));
        setPlanetSize(tag.getFloat("PlanetSize"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("PlanetName", getPlanetName());
        tag.putInt("PlanetColor", getPlanetColor());
        tag.putFloat("PlanetSize", getPlanetSize());
    }
}
