package com.spacemod.colony;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/**
 * Упрощённая колония «Заря» из оригинального кода.
 * Один «сол» за активацию. 12 солов максимум.
 */
public class ColonyManager {

    private static final String KEY = "SpaceModColony";

    public static CompoundTag getData(Player player) {
        CompoundTag p = player.getPersistentData();
        if (!p.contains(KEY)) {
            CompoundTag d = new CompoundTag();
            d.putInt("Sol", 0);
            d.putInt("Oxygen", 90);
            d.putInt("Water", 48);
            d.putInt("Food", 52);
            d.putInt("Energy", 40);
            d.putInt("Iron", 55);
            d.putInt("Titanium", 20);
            d.putInt("Greenhouse", 0);
            d.putInt("Pump", 0);
            d.putInt("Lab", 0);
            d.putInt("Solar", 1);
            d.putInt("Research", 0);
            d.putBoolean("Active", false);
            p.put(KEY, d);
        }
        return p.getCompound(KEY);
    }

    public static void startOrAdvance(ServerPlayer player) {
        CompoundTag d = getData(player);
        if (!d.getBoolean("Active")) {
            d.putBoolean("Active", true);
            player.sendSystemMessage(Component.literal("§a§lКолония «Заря» основана!"));
            player.sendSystemMessage(Component.literal("§7Цель: продержаться 12 солов. ПКМ планшетом колонии — следующий сол."));
            showStatus(player);
            return;
        }

        int sol = d.getInt("Sol") + 1;
        if (sol > 12) {
            player.sendSystemMessage(Component.literal("§a§lКолония успешно завершила 12 солов!"));
            showStatus(player);
            return;
        }
        d.putInt("Sol", sol);
        player.sendSystemMessage(Component.literal("§6--- Сол " + sol + " ---"));

        // События
        switch (sol) {
            case 2 -> { change(d, "Energy", -10); player.sendSystemMessage(Component.literal("§cПылевая буря: -10 энергии")); }
            case 4 -> { change(d, "Water", 12); player.sendSystemMessage(Component.literal("§bНайден подповерхностный лёд: +12 воды")); }
            case 5 -> { change(d, "Iron", -3); player.sendSystemMessage(Component.literal("§7Ремонт шлюза: -3 железа")); }
            case 7 -> { change(d, "Energy", -8); player.sendSystemMessage(Component.literal("§cСолнечная вспышка: -8 энергии")); }
            case 9 -> { change(d, "Iron", 8); change(d, "Titanium", 2); player.sendSystemMessage(Component.literal("§aМетеорит: +8 железа, +2 титана")); }
            case 11 -> { change(d, "Food", 6); player.sendSystemMessage(Component.literal("§aУрожай: +6 еды")); }
            default -> player.sendSystemMessage(Component.literal("§7Штатный день"));
        }

        // Строительство по расписанию
        if (sol == 2) tryBuild(player, d, "Greenhouse", 12, 4);
        if (sol == 4) tryBuild(player, d, "Pump", 10, 5);
        if (sol == 6) tryBuild(player, d, "Lab", 15, 4);
        if (sol == 8) { d.putInt("Solar", d.getInt("Solar") + 1); player.sendSystemMessage(Component.literal("§aПостроена солнечная ферма")); }

        // Производство и потребление
        int solar = d.getInt("Solar");
        int gh = d.getInt("Greenhouse");
        int pump = d.getInt("Pump");
        int lab = d.getInt("Lab");
        int energyGain = solar * 12;
        int energyUse = 4 + gh * 2 + pump * 2 + lab * 3;
        change(d, "Energy", energyGain - energyUse);
        change(d, "Food", gh * 4 * 5 - 16); // 4 crew * 4
        change(d, "Oxygen", gh * 4 * 4 - 16);
        change(d, "Water", pump * 4 * 4 - gh * 2 - 12);

        if (lab > 0) {
            int pts = lab * 5;
            d.putInt("Research", d.getInt("Research") + pts);
            player.sendSystemMessage(Component.literal("§bЛаборатория: +" + pts + " исследований"));
        }

        // Проверка дефицита
        for (String res : new String[]{"Oxygen", "Water", "Food", "Energy"}) {
            if (d.getInt(res) < 0) {
                d.putInt(res, 0);
                player.sendSystemMessage(Component.literal("§c§lДефицит " + res + "!"));
            }
        }

        showStatus(player);
    }

    private static void tryBuild(ServerPlayer player, CompoundTag d, String type, int iron, int titan) {
        if (d.getInt("Iron") >= iron && d.getInt("Titanium") >= titan) {
            change(d, "Iron", -iron);
            change(d, "Titanium", -titan);
            d.putInt(type, d.getInt(type) + 1);
            player.sendSystemMessage(Component.literal("§aПостроен объект: " + type));
        } else {
            player.sendSystemMessage(Component.literal("§cНе хватает материалов для " + type));
        }
    }

    private static void change(CompoundTag d, String key, int amount) {
        d.putInt(key, d.getInt(key) + amount);
    }

    public static void showStatus(ServerPlayer player) {
        CompoundTag d = getData(player);
        player.sendSystemMessage(Component.literal("§6=== Колония «Заря» — Сол " + d.getInt("Sol") + "/12 ==="));
        player.sendSystemMessage(Component.literal("§7O₂:" + d.getInt("Oxygen") + " Вода:" + d.getInt("Water") +
                " Еда:" + d.getInt("Food") + " Энергия:" + d.getInt("Energy")));
        player.sendSystemMessage(Component.literal("§7Железо:" + d.getInt("Iron") + " Титан:" + d.getInt("Titanium") +
                " Исследования:" + d.getInt("Research")));
        player.sendSystemMessage(Component.literal("§7Теплицы:" + d.getInt("Greenhouse") + " Буры:" + d.getInt("Pump") +
                " Лабы:" + d.getInt("Lab") + " Солнце:" + d.getInt("Solar")));
    }
}
