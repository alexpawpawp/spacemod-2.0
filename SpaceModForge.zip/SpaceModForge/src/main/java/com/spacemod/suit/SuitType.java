package com.spacemod.suit;

import java.util.Map;
import java.util.Set;

/**
 * Типы скафандров и на каких измерениях они защищают.
 */
public enum SuitType {
    BASIC("basic_suit", "Базовый скафандр"),
    HEAT("heat_suit", "Термостойкий скафандр"),
    COLD("cold_suit", "Крио-скафандр"),
    PRESSURE("pressure_suit", "Глубокий скафандр"),
    RADIATION("radiation_suit", "Радиационный скафандр"),
    TOXIC("toxic_suit", "Химзащитный скафандр"),
    VACUUM("vacuum_suit", "Вакуумный скафандр"),
    GIANT("giant_suit", "Атмосферный скафандр гигантов"),
    STAR("star_suit", "Звёздный скафандр");

    public final String itemId;
    public final String displayName;

    SuitType(String itemId, String displayName) {
        this.itemId = itemId;
        this.displayName = displayName;
    }

    /** Какой скафандр нужен на измерении (id без namespace) */
    public static final Map<String, SuitType> REQUIRED = Map.ofEntries(
            Map.entry("mercury", HEAT),
            Map.entry("venus", TOXIC),
            Map.entry("mars", BASIC),
            Map.entry("moon", VACUUM),
            Map.entry("europa", COLD),
            Map.entry("titan", TOXIC),
            Map.entry("pluto", COLD),
            Map.entry("jupiter", GIANT),
            Map.entry("saturn", GIANT),
            Map.entry("uranus", GIANT),
            Map.entry("neptune", GIANT),
            Map.entry("kepler_90g", GIANT),
            Map.entry("proxima_b", RADIATION),
            Map.entry("proxima_d", HEAT),
            Map.entry("trappist_1e", BASIC),
            Map.entry("trappist_1f", COLD),
            Map.entry("kepler_90i", HEAT),
            Map.entry("gliese_667_cc", RADIATION),
            Map.entry("gliese_667_ce", COLD),
            Map.entry("tau_ceti_e", TOXIC),
            Map.entry("tau_ceti_f", BASIC),
            Map.entry("gj273_b", BASIC),
            Map.entry("gj273_c", COLD),
            Map.entry("toi700_d", BASIC),
            Map.entry("toi700_e", BASIC),
            Map.entry("wolf1061_c", PRESSURE),
            Map.entry("wolf1061_d", COLD),
            Map.entry("cancri_e", HEAT),
            Map.entry("cancri_f", PRESSURE),
            Map.entry("black_hole", RADIATION),
            Map.entry("open_space", VACUUM),
            Map.entry("star_sol", STAR),
            Map.entry("star_proxima", STAR),
            Map.entry("star_trappist", STAR),
            Map.entry("star_kepler90", STAR),
            Map.entry("star_gliese", STAR),
            Map.entry("star_tau_ceti", STAR),
            Map.entry("star_luyten", STAR),
            Map.entry("star_toi700", STAR),
            Map.entry("star_wolf", STAR),
            Map.entry("star_cancri", STAR)
    );
}
