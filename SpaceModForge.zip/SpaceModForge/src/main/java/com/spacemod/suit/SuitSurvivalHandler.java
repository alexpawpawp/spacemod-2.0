package com.spacemod.suit;

import com.spacemod.ModItems;
import com.spacemod.SpaceMod;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = SpaceMod.MOD_ID)
public class SuitSurvivalHandler {

    private static final Map<SuitType, RegistryObject<Item>> SUIT_ITEMS = new HashMap<>();

    public static void bind(SuitType type, RegistryObject<Item> item) {
        SUIT_ITEMS.put(type, item);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.tickCount % 40 != 0) return; // каждые 2 сек

        String dimPath = player.level().dimension().location().getPath();
        String namespace = player.level().dimension().location().getNamespace();
        if (!namespace.equals(SpaceMod.MOD_ID)) return;

        SuitType required = SuitType.REQUIRED.get(dimPath);
        if (required == null) return;

        if (hasSuit(player, required)) {
            // лёгкая защита
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 50, 0, true, false));
            return;
        }

        // Без нужного скафандра — урон среды
        player.hurt(player.damageSources().generic(), 2.0f);
        player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 60, 0, true, false));
        if (player.tickCount % 200 == 0) {
            player.sendSystemMessage(Component.literal("§cСреда враждебна! Нужен: §e" + required.displayName));
        }
    }

    public static boolean hasSuit(Player player, SuitType type) {
        RegistryObject<Item> ref = SUIT_ITEMS.get(type);
        if (ref == null) return false;
        Item need = ref.get();
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(need)) return true;
        }
        // также смотрим броню / offhand
        if (player.getOffhandItem().is(need)) return true;
        for (ItemStack a : player.getArmorSlots()) {
            if (a.is(need)) return true;
        }
        return false;
    }
}
