package com.spacemod;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, SpaceMod.MOD_ID);

    public static final RegistryObject<Block> MOON_STONE = reg("moon_stone",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.STONE).strength(1.5f)));

    public static final RegistryObject<Block> MARTIAN_BASALT = reg("martian_basalt",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.BASALT).strength(2.0f)));

    public static final RegistryObject<Block> TITANIUM_ORE = reg("titanium_ore",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_ORE)
                    .strength(3.5f).requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> SPACE_ICE = reg("space_ice",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.PACKED_ICE).strength(0.6f)));

    public static final RegistryObject<Block> SOLAR_PANEL = reg("solar_panel",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(2.5f)));

    public static final RegistryObject<Block> NETHERITE_CRYSTAL_BLOCK = reg("netherite_crystal_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.AMETHYST_BLOCK)
                    .strength(4.0f).requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> RADIO_TELESCOPE = reg("radio_telescope",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(3.0f).noOcclusion()));

    public static final RegistryObject<Block> WARP_CORE = reg("warp_core",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.OBSIDIAN)
                    .strength(8.0f).requiresCorrectToolForDrops().lightLevel(s -> 10)));

    public static final RegistryObject<Block> MERCURY_ROCK = reg("mercury_rock",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.STONE).strength(2.0f)));

    public static final RegistryObject<Block> VENUS_BASALT = reg("venus_basalt",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.BASALT).strength(2.2f)));

    public static final RegistryObject<Block> RED_SAND_BLOCK = reg("red_sand_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.RED_SAND).strength(0.5f)));

    public static final RegistryObject<Block> LAVA_BASALT = reg("lava_basalt",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.BASALT)
                    .strength(2.5f).lightLevel(s -> 4)));

    public static final RegistryObject<Block> BLUE_BASALT = reg("blue_basalt",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.BASALT).strength(2.0f)));

    public static final RegistryObject<Block> RED_BASALT = reg("red_basalt",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.BASALT).strength(2.0f)));

    public static final RegistryObject<Block> SILICATE_BLOCK = reg("silicate_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.SANDSTONE).strength(1.8f)));

    public static final RegistryObject<Block> METHANE_ICE_BLOCK = reg("methane_ice_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.BLUE_ICE).strength(0.7f)));

    public static final RegistryObject<Block> AMMONIA_ICE_BLOCK = reg("ammonia_ice_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.PACKED_ICE).strength(0.7f)));

    public static final RegistryObject<Block> NITROGEN_ICE_BLOCK = reg("nitrogen_ice_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.BLUE_ICE).strength(0.6f)));


    public static final RegistryObject<Block> SPACE_DOME = reg("space_dome",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.GLASS).strength(2.0f).noOcclusion()));

    // Инопланетная растительность (семена/блоки)
    public static final RegistryObject<Block> MARS_THORN = reg("mars_thorn",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.SWEET_BERRY_BUSH).noOcclusion()));
    public static final RegistryObject<Block> EUROPA_FROND = reg("europa_frond",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.KELP).noOcclusion()));
    public static final RegistryObject<Block> TITAN_CAP = reg("titan_cap",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.BROWN_MUSHROOM).noOcclusion()));
    public static final RegistryObject<Block> PROXIMA_GLOW = reg("proxima_glow",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.GLOW_LICHEN).lightLevel(s -> 7).noOcclusion()));
    public static final RegistryObject<Block> VENUS_SPORE = reg("venus_spore",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.CRIMSON_FUNGUS).noOcclusion()));
    public static final RegistryObject<Block> TRAPPIST_LEAF = reg("trappist_leaf",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.OAK_LEAVES).noOcclusion()));
    public static final RegistryObject<Block> WOLF_VINE = reg("wolf_vine",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.VINE).noOcclusion()));
    public static final RegistryObject<Block> CANCRI_BURNWEED = reg("cancri_burnweed",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.NETHER_SPROUTS).noOcclusion()));
    public static final RegistryObject<Block> VOID_MOSS = reg("void_moss",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.MOSS_CARPET).noOcclusion()));
    public static final RegistryObject<Block> ICE_BLOOM = reg("ice_bloom",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.BLUE_ORCHID).noOcclusion()));

    private static <T extends Block> RegistryObject<T> reg(String name, Supplier<T> block) {
        RegistryObject<T> toReturn = BLOCKS.register(name, block);
        ModItems.ITEMS.register(name, () -> new BlockItem(toReturn.get(), new Item.Properties()));
        return toReturn;
    }

    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
}
