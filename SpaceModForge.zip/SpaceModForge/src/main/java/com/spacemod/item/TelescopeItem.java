package com.spacemod.item;

import com.spacemod.data.SpaceData;
import com.spacemod.entity.RocketEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Телескоп — показывает информацию о текущем измерении и «виде на звезду».
 */
public class TelescopeItem extends Item {
    public TelescopeItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            var dim = level.dimension();
            String place = "Земля (Верхний мир)";
            String sky = "Голубое небо, Солнце";
            String note = "Домашняя планета";

            if (dim.equals(RocketEntity.MARS)) {
                place = "Марс";
                sky = "Розово-красное небо, Солнце выглядит меньше и бледнее";
                note = "Тонкая атмосфера CO₂, пылевые бури, каньоны";
            } else if (dim.equals(RocketEntity.MOON)) {
                place = "Луна";
                sky = "Чёрное небо без атмосферы, Земля висит на горизонте";
                note = "Нет воздуха, резкие тени, реголит";
            } else if (dim.equals(RocketEntity.EUROPA)) {
                place = "Европа";
                sky = "Тёмно-синее небо, Юпитер занимает большую часть неба";
                note = "Ледяная кора, подлёдный океан";
            }

            sp.sendSystemMessage(Component.literal("§b§l=== Телескоп ==="));
            sp.sendSystemMessage(Component.literal("§7Место: §f" + place));
            sp.sendSystemMessage(Component.literal("§7Небо: §f" + sky));
            sp.sendSystemMessage(Component.literal("§7Особенности: §f" + note));
            sp.sendSystemMessage(Component.literal("§8(Полноценная динамическая орбитальная симуляция — в будущих версиях)"));
        }
        return InteractionResultHolder.success(player.getItemInHand(hand));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7ПКМ — осмотреть небо и окрестности"));
    }
}
