package com.spacemod.item;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.core.registries.Registries;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Возвратная ракета — телепортирует обратно в Верхний мир.
 */
public class ReturnRocketItem extends Item {

    public ReturnRocketItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }

        if (!(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResultHolder.fail(stack);
        }

        ResourceKey<Level> overworld = Level.OVERWORLD;
        ServerLevel target = serverPlayer.server.getLevel(overworld);

        if (target == null) {
            player.sendSystemMessage(Component.literal("§cНе удалось найти Верхний мир."));
            return InteractionResultHolder.fail(stack);
        }

        // Телепорт на точку возрождения или 0,100,0
        var respawn = serverPlayer.getRespawnPosition();
        double x = respawn != null ? respawn.getX() + 0.5 : 0.5;
        double y = respawn != null ? respawn.getY() + 1.0 : 100.0;
        double z = respawn != null ? respawn.getZ() + 0.5 : 0.5;

        if (serverPlayer.getRespawnDimension() != overworld) {
            x = 0.5; y = 100.0; z = 0.5;
        }

        serverPlayer.teleportTo(target, x, y, z, serverPlayer.getYRot(), serverPlayer.getXRot());
        serverPlayer.sendSystemMessage(Component.literal("§a§lВозвращение на Землю завершено."));
        serverPlayer.sendSystemMessage(Component.literal("§7Станция «Аврора» приняла корабль."));

        // Расходуем предмет (одноразовая)
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }

        return InteractionResultHolder.success(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7ПКМ — вернуться на Землю"));
        tooltip.add(Component.literal("§8Работает из любого измерения"));
    }
}
