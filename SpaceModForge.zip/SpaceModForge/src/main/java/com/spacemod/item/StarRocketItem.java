package com.spacemod.item;

import com.spacemod.ModItems;
import com.spacemod.entity.RocketEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.core.BlockPos;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Звёздная ракета — только на звёзды, требует звёздное топливо.
 */
public class StarRocketItem extends Item {

    private static final String[] STARS = {
            "star_sol", "star_proxima", "star_trappist", "star_kepler90", "star_gliese",
            "star_tau_ceti", "star_luyten", "star_toi700", "star_wolf", "star_cancri"
    };
    private static final String[] NAMES = {
            "Солнце", "Проксима Центавра", "TRAPPIST-1", "Kepler-90", "Глизе 667 C",
            "Тау Кита", "Звезда Лейтена", "TOI 700", "Wolf 1061", "55 Cancri"
    };

    public StarRocketItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);

        // Нужен star_fuel
        boolean fuel = false;
        for (ItemStack inv : player.getInventory().items) {
            if (inv.is(ModItems.STAR_FUEL.get())) {
                inv.shrink(1);
                fuel = true;
                break;
            }
        }
        if (!fuel) {
            player.sendSystemMessage(Component.literal("§cНужно §6Звёздное топливо§c!"));
            return InteractionResultHolder.fail(stack);
        }

        int idx = stack.getOrCreateTag().getInt("StarIndex");
        if (player.isShiftKeyDown()) {
            idx = (idx + 1) % STARS.length;
            stack.getOrCreateTag().putInt("StarIndex", idx);
            player.sendSystemMessage(Component.literal("§eЦель: §6" + NAMES[idx]));
            return InteractionResultHolder.success(stack);
        }

        String dimId = STARS[idx];
        String name = NAMES[idx];
        if (!(player instanceof ServerPlayer sp)) return InteractionResultHolder.fail(stack);

        ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, new ResourceLocation("spacemod", dimId));
        ServerLevel target = sp.server.getLevel(key);
        if (target == null) {
            sp.sendSystemMessage(Component.literal("§cЗвезда §e" + name + "§c не загружена."));
            return InteractionResultHolder.fail(stack);
        }

        sp.sendSystemMessage(Component.literal("§6§lЗвёздная ракета стартует к: " + name));
        sp.sendSystemMessage(Component.literal("§cВНИМАНИЕ: экстремальная гравитация и жар!"));
        BlockPos pos = target.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlockPos.ZERO);
        sp.teleportTo(target, pos.getX() + 0.5, pos.getY() + 2, pos.getZ() + 0.5, sp.getYRot(), sp.getXRot());
        sp.sendSystemMessage(Component.literal("§aПосадка на корональный слой «" + name + "»."));
        sp.sendSystemMessage(Component.literal("§7Нужен §eЗвёздный скафандр§7. В биоме бродит §cСтраж звезды§7."));

        return InteractionResultHolder.success(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        int idx = stack.getOrCreateTag().getInt("StarIndex");
        tooltip.add(Component.literal("§6Цель: " + NAMES[idx % NAMES.length]));
        tooltip.add(Component.literal("§8ПКМ — полёт (нужно звёздное топливо)"));
        tooltip.add(Component.literal("§8Shift+ПКМ — смена звезды"));
    }
}
