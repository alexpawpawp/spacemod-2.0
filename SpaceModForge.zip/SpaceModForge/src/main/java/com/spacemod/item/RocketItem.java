package com.spacemod.item;

import com.spacemod.ModItems;
import com.spacemod.client.PlanetSelectScreen;
import com.spacemod.data.SpaceData;
import com.spacemod.entity.RocketEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class RocketItem extends Item {

    private static final List<String> ALL = new ArrayList<>();
    static {
        for (SpaceData.Planet p : SpaceData.PLANETS) ALL.add(p.name());
        for (SpaceData.Planet p : SpaceData.MOONS) ALL.add(p.name());
        for (SpaceData.StarSystem s : SpaceData.STAR_SYSTEMS)
            for (SpaceData.Planet p : s.planets()) ALL.add(p.name());
        ALL.add("Стрелец A*");
        ALL.add("M87*");
        ALL.add("Открытый космос");
    }

    public RocketItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // Shift + ПКМ = открыть GUI выбора (только клиент)
        if (player.isShiftKeyDown()) {
            if (level.isClientSide) {
                openGui(stack);
            }
            return InteractionResultHolder.success(stack);
        }

        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }

        // Проверка топлива
        boolean hasFuel = false;
        for (ItemStack inv : player.getInventory().items) {
            if (inv.is(ModItems.FUEL_TANK.get())) {
                hasFuel = true;
                inv.shrink(1);
                break;
            }
        }
        if (!hasFuel) {
            player.sendSystemMessage(Component.literal("§cНужен Топливный бак!"));
            return InteractionResultHolder.fail(stack);
        }

        // Цель: либо из NBT (GUI), либо следующая по кругу
        String dest;
        if (stack.getOrCreateTag().contains("SelectedDest")) {
            dest = stack.getTag().getString("SelectedDest");
        } else {
            int idx = stack.getOrCreateTag().getInt("DestIndex");
            dest = ALL.get(idx % ALL.size());
            stack.getOrCreateTag().putInt("DestIndex", (idx + 1) % ALL.size());
        }

        Vec3 pos = player.position().add(player.getLookAngle().scale(2));
        RocketEntity rocket = new RocketEntity(level, pos.x, pos.y, pos.z);
        rocket.setDestination(dest);
        rocket.setFuel(1);
        rocket.setPilot(player);
        level.addFreshEntity(rocket);
        rocket.launch();

        return InteractionResultHolder.success(stack);
    }

    @OnlyIn(Dist.CLIENT)
    private void openGui(ItemStack stack) {
        Minecraft.getInstance().setScreen(new PlanetSelectScreen(stack));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (stack.getOrCreateTag().contains("SelectedDest")) {
            tooltip.add(Component.literal("§aЦель: §e" + stack.getTag().getString("SelectedDest")));
        } else {
            int idx = stack.getOrCreateTag().getInt("DestIndex");
            tooltip.add(Component.literal("§7Следующая: §e" + ALL.get(idx % ALL.size())));
        }
        tooltip.add(Component.literal("§8ПКМ — запуск"));
        tooltip.add(Component.literal("§8Shift+ПКМ — выбор планеты"));
    }
}
