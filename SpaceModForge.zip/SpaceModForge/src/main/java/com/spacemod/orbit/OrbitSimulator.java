package com.spacemod.orbit;

import java.util.ArrayList;
import java.util.List;

/**
 * Упрощённый симулятор круговых орбит.
 * Планеты движутся по кругу с разными периодами (в условных единицах).
 */
public class OrbitSimulator {

    public record Body(String name, double orbitRadius, double periodDays, double size, int color) {
        /** Угол в радианах на момент time (в условных «днях») */
        public double angle(double time) {
            return (2 * Math.PI * time / periodDays) % (2 * Math.PI);
        }
        public double x(double time) {
            return Math.cos(angle(time)) * orbitRadius;
        }
        public double y(double time) {
            return Math.sin(angle(time)) * orbitRadius;
        }
    }

    public static final List<Body> SOLAR_SYSTEM = List.of(
            new Body("Меркурий", 0.4, 88, 4, 0xB0B0B0),
            new Body("Венера", 0.7, 225, 6, 0xE8C87A),
            new Body("Земля", 1.0, 365, 6, 0x4A90D9),
            new Body("Марс", 1.5, 687, 5, 0xC1440E),
            new Body("Юпитер", 5.2, 4333, 14, 0xC88B3A),
            new Body("Сатурн", 9.5, 10759, 12, 0xE6D5A8),
            new Body("Уран", 19.2, 30687, 9, 0x7FDBDA),
            new Body("Нептун", 30.1, 60190, 9, 0x2E5A88),
            new Body("Плутон", 39.5, 90560, 3, 0xC4A882)
    );

    public static final List<Body> MOONS = List.of(
            new Body("Луна", 0.15, 27, 3, 0xC0C0C0),   // вокруг Земли
            new Body("Европа", 0.4, 3.5, 3, 0xB8D4E8), // вокруг Юпитера
            new Body("Титан", 0.5, 16, 4, 0xE8B060)    // вокруг Сатурна
    );

    /** Текущее время симуляции (накапливается) */
    private static double simTime = 0;

    public static void tick(double deltaDays) {
        simTime += deltaDays;
    }

    public static double getTime() {
        return simTime;
    }

    public static void setTime(double t) {
        simTime = t;
    }

    public static List<Body> getAllBodies() {
        List<Body> all = new ArrayList<>(SOLAR_SYSTEM);
        all.addAll(MOONS);
        return all;
    }
}
