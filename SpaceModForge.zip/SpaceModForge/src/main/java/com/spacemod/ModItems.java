package com.spacemod;

import com.spacemod.item.RocketItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SpaceMod.MOD_ID);

    // === Снаряжение ===
    public static final RegistryObject<Item> OXYGEN_TANK = reg("oxygen_tank", 16);
    public static final RegistryObject<Item> SPACE_SUIT = reg("space_suit", 1);
    public static final RegistryObject<Item> DRILL = ITEMS.register("drill",
            () -> new Item(new Item.Properties().stacksTo(1).durability(500)));
    public static final RegistryObject<Item> FUEL_TANK = reg("fuel_tank", 8);
    public static final RegistryObject<Item> RESEARCH_PROBE = reg("research_probe", 16);
    public static final RegistryObject<Item> GRAVITY_SCANNER = reg("gravity_scanner", 1);

    // === Ракета ===
    public static final RegistryObject<Item> ROCKET = ITEMS.register("rocket",
            () -> new RocketItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> RETURN_ROCKET = ITEMS.register("return_rocket",
            () -> new com.spacemod.item.ReturnRocketItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> MISSION_TABLET = ITEMS.register("mission_tablet",
            () -> new com.spacemod.item.MissionTabletItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> COLONY_TABLET = ITEMS.register("colony_tablet",
            () -> new com.spacemod.item.ColonyTabletItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> TELESCOPE = ITEMS.register("telescope",
            () -> new com.spacemod.item.TelescopeItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> SPACE_PROBE = ITEMS.register("space_probe",
            () -> new com.spacemod.item.SpaceProbeItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> ORBIT_MAP = ITEMS.register("orbit_map",
            () -> new com.spacemod.item.OrbitMapItem(new Item.Properties().stacksTo(1)));

    // Скафандры под среды
    public static final RegistryObject<Item> BASIC_SUIT = reg("basic_suit", 1);
    public static final RegistryObject<Item> HEAT_SUIT = reg("heat_suit", 1);
    public static final RegistryObject<Item> COLD_SUIT = reg("cold_suit", 1);
    public static final RegistryObject<Item> PRESSURE_SUIT = reg("pressure_suit", 1);
    public static final RegistryObject<Item> RADIATION_SUIT = reg("radiation_suit", 1);
    public static final RegistryObject<Item> TOXIC_SUIT = reg("toxic_suit", 1);
    public static final RegistryObject<Item> VACUUM_SUIT = reg("vacuum_suit", 1);
    public static final RegistryObject<Item> GIANT_SUIT = reg("giant_suit", 1);

    public static final RegistryObject<Item> STAR_ROCKET = ITEMS.register("star_rocket",
            () -> new com.spacemod.item.StarRocketItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> STAR_SUIT = reg("star_suit", 1);
    public static final RegistryObject<Item> STAR_FUEL = reg("star_fuel", 8);

    public static final RegistryObject<Item> SOLAR_CORE_SHARD = reg("solar_core_shard");
    public static final RegistryObject<Item> PROTON_CRYSTAL = reg("proton_crystal");
    public static final RegistryObject<Item> STELLAR_PLASMA = reg("stellar_plasma");
    public static final RegistryObject<Item> CORONAL_THREAD = reg("coronal_thread");
    public static final RegistryObject<Item> FUSION_DUST = reg("fusion_dust");
    public static final RegistryObject<Item> STAR_IRON = reg("star_iron");
    public static final RegistryObject<Item> HELIOS_GEM = reg("helios_gem");
    public static final RegistryObject<Item> RED_DWARF_ASH = reg("red_dwarf_ash");
    public static final RegistryObject<Item> WHITE_FLAME_INGOT = reg("white_flame_ingot");
    public static final RegistryObject<Item> GUARDIAN_CORE = reg("guardian_core");



    public static final RegistryObject<Item> ROVER = ITEMS.register("rover",
            () -> new com.spacemod.probe.RoverItem(new Item.Properties().stacksTo(4)));

    // Плоды / образцы растительности (эффект при еде — через события, без подсказок)
    public static final RegistryObject<Item> MARS_BERRY = ITEMS.register("mars_berry",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));
    public static final RegistryObject<Item> EUROPA_FRUIT = ITEMS.register("europa_fruit",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));
    public static final RegistryObject<Item> TITAN_FUNGUS = ITEMS.register("titan_fungus",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));
    public static final RegistryObject<Item> PROXIMA_POD = ITEMS.register("proxima_pod",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));
    public static final RegistryObject<Item> VENUS_POD = ITEMS.register("venus_pod",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));
    public static final RegistryObject<Item> TRAPPIST_APPLE = ITEMS.register("trappist_apple",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));
    public static final RegistryObject<Item> WOLF_BERRY = ITEMS.register("wolf_berry",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));
    public static final RegistryObject<Item> CANCRI_FRUIT = ITEMS.register("cancri_fruit",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));
    public static final RegistryObject<Item> VOID_SPORES = ITEMS.register("void_spores",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));
    public static final RegistryObject<Item> ICE_PETAL = ITEMS.register("ice_petal",
            () -> new Item(new Item.Properties().stacksTo(16).food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3f).alwaysEat().build())));



    // === Металлы и руды ===
    public static final RegistryObject<Item> TITANIUM_INGOT = reg("titanium_ingot");
    public static final RegistryObject<Item> TITANIUM_DUST = reg("titanium_dust");
    public static final RegistryObject<Item> COBALT = reg("cobalt");
    public static final RegistryObject<Item> TUNGSTEN = reg("tungsten");
    public static final RegistryObject<Item> RARE_METALS = reg("rare_metals");
    public static final RegistryObject<Item> THERMOMETAL = reg("thermometal");
    public static final RegistryObject<Item> DEEP_METAL = reg("deep_metal");

    // === Газы и кристаллы ===
    public static final RegistryObject<Item> HELIUM3 = reg("helium3");
    public static final RegistryObject<Item> HYDROGEN_CRYSTAL = reg("hydrogen_crystal");
    public static final RegistryObject<Item> PLASMA_CRYSTAL = reg("plasma_crystal");
    public static final RegistryObject<Item> THERMO_CRYSTAL = reg("thermo_crystal");
    public static final RegistryObject<Item> ENERGY_CRYSTAL = reg("energy_crystal");
    public static final RegistryObject<Item> URANIUM_CRYSTAL = reg("uranium_crystal");
    public static final RegistryObject<Item> DEEP_CRYSTAL = reg("deep_crystal");
    public static final RegistryObject<Item> CRYO_CRYSTAL = reg("cryo_crystal");
    public static final RegistryObject<Item> CARBON_CRYSTAL = reg("carbon_crystal");
    public static final RegistryObject<Item> ICE_OPAL = reg("ice_opal");
    public static final RegistryObject<Item> SALT_CRYSTAL = reg("salt_crystal");
    public static final RegistryObject<Item> NETHERITE_CRYSTAL_ITEM = reg("netherite_crystal_item");

    // === Льды ===
    public static final RegistryObject<Item> WATER_ICE = reg("water_ice");
    public static final RegistryObject<Item> NITROGEN_ICE = reg("nitrogen_ice");
    public static final RegistryObject<Item> METHANE_ICE = reg("methane_ice");
    public static final RegistryObject<Item> AMMONIA_ICE = reg("ammonia_ice");
    public static final RegistryObject<Item> MARTIAN_ICE = reg("martian_ice");
    public static final RegistryObject<Item> RING_ICE = reg("ring_ice");
    public static final RegistryObject<Item> NEPTUNE_ICE = reg("neptune_ice");
    public static final RegistryObject<Item> FROZEN_METHANE = reg("frozen_methane");
    public static final RegistryObject<Item> EXO_ICE = reg("exo_ice");

    // === Органика ===
    public static final RegistryObject<Item> BIOLUMINESCENT_MUSHROOM = reg("bioluminescent_mushroom");
    public static final RegistryObject<Item> ORGANIC_COMPOUNDS = reg("organic_compounds");
    public static final RegistryObject<Item> ORGANIC_MOLECULES = reg("organic_molecules");
    public static final RegistryObject<Item> HYDRATED_MINERALS = reg("hydrated_minerals");

    // === Прочие ресурсы ===
    public static final RegistryObject<Item> SULFUR = reg("sulfur");
    public static final RegistryObject<Item> RED_SAND = reg("red_sand");
    public static final RegistryObject<Item> RED_QUARTZ = reg("red_quartz");
    public static final RegistryObject<Item> LAVA_STONE = reg("lava_stone");
    public static final RegistryObject<Item> VOLCANIC_GLASS = reg("volcanic_glass");
    public static final RegistryObject<Item> ATMOSPHERIC_GAS = reg("atmospheric_gas");
    public static final RegistryObject<Item> STORM_GAS = reg("storm_gas");
    public static final RegistryObject<Item> METALLIC_HYDROGEN = reg("metallic_hydrogen");
    public static final RegistryObject<Item> PLUTONITE = reg("plutonite");
    public static final RegistryObject<Item> MERCURY_STONE = reg("mercury_stone");
    public static final RegistryObject<Item> SILICATE = reg("silicate");
    public static final RegistryObject<Item> SILICATE_CRYSTALS = reg("silicate_crystals");
    public static final RegistryObject<Item> CARBONATES = reg("carbonates");
    public static final RegistryObject<Item> LUNAR_REGOLITH = reg("lunar_regolith");
    public static final RegistryObject<Item> METHANE = reg("methane");
    public static final RegistryObject<Item> ETHANE = reg("ethane");
    public static final RegistryObject<Item> SALTS = reg("salts");
    public static final RegistryObject<Item> SUBGLACIAL_SAMPLE = reg("subglacial_sample");

    // === Научные данные ===
    public static final RegistryObject<Item> GRAVITATIONAL_WAVE_DATA = reg("gravitational_wave_data");
    public static final RegistryObject<Item> ACCRETION_DISK_ENERGY = reg("accretion_disk_energy");
    public static final RegistryObject<Item> RELATIVISTIC_JET_SPECTRUM = reg("relativistic_jet_spectrum");
    public static final RegistryObject<Item> NEUTRON_DENSITY_DATA = reg("neutron_density_data");
    public static final RegistryObject<Item> PULSAR_MAP = reg("pulsar_map");
    public static final RegistryObject<Item> MAGNETIC_FLARE_DATA = reg("magnetic_flare_data");
    public static final RegistryObject<Item> COSMIC_DUST_SAMPLE = reg("cosmic_dust_sample");
    public static final RegistryObject<Item> STAR_CLUSTER_MAP = reg("star_cluster_map");
    public static final RegistryObject<Item> SHOCKWAVE_MAP = reg("shockwave_map");
    public static final RegistryObject<Item> GAMMA_BURST_DATA = reg("gamma_burst_data");
    public static final RegistryObject<Item> ROGUE_PLANET_DATA = reg("rogue_planet_data");
    public static final RegistryObject<Item> PROTOPLANETARY_DISK_MAP = reg("protoplanetary_disk_map");
    public static final RegistryObject<Item> CLUSTER_CATALOG = reg("cluster_catalog");
    public static final RegistryObject<Item> BRIGHTNESS_GRAPH = reg("brightness_graph");

    // === Технологии ===
    public static final RegistryObject<Item> IMPROVED_RADAR_BLUEPRINT = reg("improved_radar_blueprint");
    public static final RegistryObject<Item> ION_ENGINE = reg("ion_engine");
    public static final RegistryObject<Item> EXOMATTER_ANALYZER = reg("exomatter_analyzer");
    public static final RegistryObject<Item> QUANTUM_COMM = reg("quantum_comm");
    public static final RegistryObject<Item> ENHANCED_SCANNER = reg("enhanced_scanner");
    public static final RegistryObject<Item> CLOSED_WATER_CYCLE = reg("closed_water_cycle");
    public static final RegistryObject<Item> PHOTOBIOREACTORS = reg("photobioreactors");
    public static final RegistryObject<Item> RADIATION_SHIELD = reg("radiation_shield");
    public static final RegistryObject<Item> GEO_DRONE = reg("geo_drone");

    private static RegistryObject<Item> reg(String name) {
        return ITEMS.register(name, () -> new Item(new Item.Properties()));
    }

    private static RegistryObject<Item> reg(String name, int maxStack) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().stacksTo(maxStack)));
    }

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
