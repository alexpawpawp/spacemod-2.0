package com.spacemod.sound;

import com.spacemod.SpaceMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SpaceMod.MOD_ID);

    public static final RegistryObject<SoundEvent> ROCKET_LAUNCH = register("rocket_launch");
    public static final RegistryObject<SoundEvent> ROCKET_LAND = register("rocket_land");
    public static final RegistryObject<SoundEvent> BLACK_HOLE_AMBIENT = register("black_hole_ambient");
    public static final RegistryObject<SoundEvent> PROBE_BEEP = register("probe_beep");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(SpaceMod.MOD_ID, name)));
    }

    public static void register(IEventBus bus) {
        SOUNDS.register(bus);
    }
}
