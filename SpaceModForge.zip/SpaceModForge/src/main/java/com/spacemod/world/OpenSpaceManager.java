package com.spacemod.world;

import com.spacemod.entity.space.PlanetCubeEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

/**
 * Вход в открытый космос и размещение планет-кубов.
 */
public class OpenSpaceManager {

    public static final ResourceKey<Level> OPEN_SPACE = ResourceKey.create(
            Registries.DIMENSION, new ResourceLocation("spacemod", "open_space"));

    // Название, цвет (RGB), размер куба, смещение X/Z от центра
    private static final Object[][] PLANETS = {
            {"Меркурий", 0xB0B0B0, 6f,  40.0, 0.0},
            {"Венера",   0xE8C87A, 10f, 70.0, 20.0},
            {"Земля",    0x4A90D9, 12f, 0.0, 100.0},
            {"Марс",     0xC1440E, 9f,  -80.0, 60.0},
            {"Юпитер",   0xC88B3A, 28f, 150.0, -40.0},
            {"Сатурн",   0xE6D5A8, 24f, -120.0, -100.0},
            {"Уран",     0x7FDBDA, 16f, 200.0, 80.0},
            {"Нептун",   0x2E5A88, 16f, -180.0, 150.0},
            {"Плутон",   0xC4A882, 5f,  250.0, -120.0},
            {"Луна",     0xC0C0C0, 4f,  15.0, 110.0},
            {"Европа",   0xB8D4E8, 5f,  165.0, -30.0},
    };

    public static void enterOpenSpace(ServerPlayer player) {
        ServerLevel space = player.server.getLevel(OPEN_SPACE);
        if (space == null) {
            player.sendSystemMessage(Component.literal("§cИзмерение «Открытый космос» не загружено."));
            return;
        }

        // Телепорт в центр «системы»
        player.teleportTo(space, 0.5, 80.0, 0.5, player.getYRot(), player.getXRot());
        player.sendSystemMessage(Component.literal("§b§lВыход в открытый космос!"));
        player.sendSystemMessage(Component.literal("§7Планеты видны как цветные кубы вокруг вас."));
        player.sendSystemMessage(Component.literal("§7ПКМ по кубу — информация. Возвратная ракета — домой."));

        // Спавним планеты, если их ещё нет рядом
        spawnPlanetsIfNeeded(space);
    }

    private static void spawnPlanetsIfNeeded(ServerLevel level) {
        // Простая проверка: если сущностей планеты мало — спавним заново
        long count = level.getEntities().getAll().stream()
                .filter(e -> e instanceof PlanetCubeEntity)
                .count();
        if (count >= PLANETS.length) return;

        // Удаляем старые и создаём заново
        level.getEntities().getAll().forEach(e -> {
            if (e instanceof PlanetCubeEntity) e.discard();
        });

        double y = 80.0;
        for (Object[] p : PLANETS) {
            String name = (String) p[0];
            int color = (Integer) p[1];
            float size = (Float) p[2];
            double x = (Double) p[3];
            double z = (Double) p[4];
            PlanetCubeEntity cube = new PlanetCubeEntity(level, x, y - size / 2, z, name, color, size);
            level.addFreshEntity(cube);
        }
    }
}
