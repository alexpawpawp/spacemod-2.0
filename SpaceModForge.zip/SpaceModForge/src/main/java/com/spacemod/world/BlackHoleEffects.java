package com.spacemod.world;

import com.spacemod.entity.RocketEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.spacemod.SpaceMod;

/**
 * Эффекты при приближении и пересечении горизонта событий чёрной дыры.
 */
@Mod.EventBusSubscriber(modid = SpaceMod.MOD_ID)
public class BlackHoleEffects {

    public static final ResourceKey<Level> BLACK_HOLE = ResourceKey.create(
            Registries.DIMENSION, new ResourceLocation("spacemod", "black_hole"));

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.level().dimension() != BLACK_HOLE) return;

        // Внутри чёрной дыры — сильные эффекты
        player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 40, 0, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 40, 1, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 40, 0, false, false));

        // Каждые 5 секунд сообщение
        if (player.tickCount % 100 == 0) {
            player.sendSystemMessage(Component.literal("§5§lГоризонт событий пересечён..."));
            player.sendSystemMessage(Component.literal("§8Пространство и время искажены. Обратного пути нет."));
            player.sendSystemMessage(Component.literal("§7Используй §fВозвратную ракету§7, чтобы вырваться (симуляция)."));
        }
    }

    /** Вызывается ракетой при выборе цели «Стрелец A*» или «M87*» */
    public static void approachBlackHole(ServerPlayer player, String name) {
        ServerLevel target = player.server.getLevel(BLACK_HOLE);
        if (target == null) {
            player.sendSystemMessage(Component.literal("§cИзмерение чёрной дыры не загружено."));
            return;
        }

        player.sendSystemMessage(Component.literal("§5§l=== Приближение к " + name + " ==="));
        player.sendSystemMessage(Component.literal("§7Гравитация растёт..."));
        player.sendSystemMessage(Component.literal("§7Приливные силы увеличиваются..."));
        player.sendSystemMessage(Component.literal("§c§lПересечение горизонта событий!"));

        player.teleportTo(target, 0.5, 64.0, 0.5, player.getYRot(), player.getXRot());
        player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0));
        player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 2));

        player.sendSystemMessage(Component.literal("§8Ты внутри. Научные данные получены."));
        player.sendSystemMessage(Component.literal("§aНаграда: данные о гравитационных волнах / энергии аккреционного диска."));
    }
}
