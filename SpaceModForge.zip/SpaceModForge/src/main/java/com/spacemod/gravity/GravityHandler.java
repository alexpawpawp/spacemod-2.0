package com.spacemod.gravity;

import com.spacemod.SpaceMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.UUID;

/**
 * Гравитация по измерениям (множитель от земной).
 * 1.0 = Земля, 0.17 = Луна, 2.64 = Юпитер и т.д.
 */
@Mod.EventBusSubscriber(modid = SpaceMod.MOD_ID)
public class GravityHandler {

    private static final UUID GRAVITY_UUID = UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");

    /** id измерения → множитель гравитации */
    public static final Map<String, Double> GRAVITY = Map.ofEntries(
            Map.entry("mercury", 0.38),
            Map.entry("venus", 0.90),
            Map.entry("earth_orbit", 1.00),
            Map.entry("mars", 0.38),
            Map.entry("jupiter", 2.64),
            Map.entry("saturn", 1.13),
            Map.entry("uranus", 0.89),
            Map.entry("neptune", 1.12),
            Map.entry("pluto", 0.07),
            Map.entry("moon", 0.17),
            Map.entry("europa", 0.13),
            Map.entry("titan", 0.14),
            Map.entry("proxima_b", 1.10),
            Map.entry("proxima_d", 0.70),
            Map.entry("trappist_1e", 0.93),
            Map.entry("trappist_1f", 0.82),
            Map.entry("kepler_90g", 1.30),
            Map.entry("kepler_90i", 1.45),
            Map.entry("gliese_667_cc", 1.20),
            Map.entry("gliese_667_ce", 0.90),
            Map.entry("tau_ceti_e", 1.10),
            Map.entry("tau_ceti_f", 0.80),
            Map.entry("gj273_b", 1.15),
            Map.entry("gj273_c", 0.72),
            Map.entry("toi700_d", 1.05),
            Map.entry("toi700_e", 0.95),
            Map.entry("wolf1061_c", 1.18),
            Map.entry("wolf1061_d", 1.30),
            Map.entry("cancri_e", 1.80),
            Map.entry("cancri_f", 1.40),
            Map.entry("open_space", 0.05),
            Map.entry("black_hole", 3.50),
            // Звёзды — очень сильная гравитация
            Map.entry("star_sol", 28.0),
            Map.entry("star_proxima", 15.0),
            Map.entry("star_trappist", 12.0),
            Map.entry("star_kepler90", 20.0),
            Map.entry("star_gliese", 14.0),
            Map.entry("star_tau_ceti", 18.0),
            Map.entry("star_luyten", 11.0),
            Map.entry("star_toi700", 13.0),
            Map.entry("star_wolf", 12.0),
            Map.entry("star_cancri", 22.0)
    );

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;

        String ns = player.level().dimension().location().getNamespace();
        String path = player.level().dimension().location().getPath();

        double mult = 1.0;
        if (ns.equals(SpaceMod.MOD_ID)) {
            mult = GRAVITY.getOrDefault(path, 1.0);
        }

        // Гравитация через entity gravity attribute (Forge)
        AttributeInstance grav = player.getAttribute(ForgeMod.ENTITY_GRAVITY.get());
        if (grav != null) {
            grav.removeModifier(GRAVITY_UUID);
            if (Math.abs(mult - 1.0) > 0.01) {
                // базовое значение Forge ~0.08; множитель относительно 1.0
                grav.addTransientModifier(new AttributeModifier(
                        GRAVITY_UUID, "spacemod_gravity", mult - 1.0,
                        AttributeModifier.Operation.MULTIPLY_TOTAL));
            }
        }

        // Дополнительно: низкая гравитация = выше прыжок
        AttributeInstance jump = player.getAttribute(Attributes.JUMP_STRENGTH);
        if (jump != null) {
            UUID jumpId = UUID.fromString("b2c3d4e5-f6a7-8901-bcde-f12345678901");
            jump.removeModifier(jumpId);
            if (mult < 0.9) {
                double jumpBoost = (1.0 / Math.max(0.1, mult)) - 1.0;
                jumpBoost = Math.min(jumpBoost, 2.5);
                jump.addTransientModifier(new AttributeModifier(
                        jumpId, "spacemod_jump", jumpBoost,
                        AttributeModifier.Operation.MULTIPLY_TOTAL));
            } else if (mult > 1.3) {
                double jumpNerf = 1.0 / mult - 1.0;
                jump.addTransientModifier(new AttributeModifier(
                        jumpId, "spacemod_jump", jumpNerf,
                        AttributeModifier.Operation.MULTIPLY_TOTAL));
            }
        }

        // Очень сильная гравитация (звёзды) — доп. урон если нет звёздного скафандра
        if (mult >= 10.0 && player.tickCount % 40 == 0) {
            // обрабатывается SuitSurvivalHandler для star dims
        }
    }
}
